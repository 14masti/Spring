package com.masti.dao;

import com.masti.model.User;

public interface UserDAO {
	
	boolean createUser(User us);

}