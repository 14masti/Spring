package com.doctorsch.spring.jdbc.controller;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.doctorsch.spring.jdbc.dao.DoctorDAO;
import com.doctorsch.spring.jdbc.model.Doctor;

@Controller
public class DoctorController {
	DoctorDAO doctordao;

	@Autowired
	public DoctorController(DoctorDAO doctordao) {
		this.doctordao = doctordao;
	}

	// @RequestMapping(value = "/user", method = RequestMethod.GET)
	// public String showForm(Model model) {
	// model.addAttribute("doctor", new Doctor()); // Initialize an empty Doctor object
	// return "user"; // Return the name of the HTML template
	// }

	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		System.out.println("Home Page Requested, locale = " + locale);

		return "home";
	}

	@RequestMapping(value = "/raju", method = RequestMethod.POST)
	public String user(@ModelAttribute("doc") Doctor doc, Model model) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

			Time avlFrom = new Time(sdf.parse(doc.getDcsc_avl_from()).getTime());
			Time avlTo = new Time(sdf.parse(doc.getDcsc_avl_to()).getTime());
			Time appSlot = new Time(sdf.parse(doc.getDcsc_app_slot()).getTime());

			doc.setDcsc_avl_from(avlFrom);
			doc.setDcsc_avl_to(avlTo);
			doc.setDcsc_app_slot(appSlot);

			boolean success = doctordao.createDoctorSchedule(doc);

			if (success) {
				return "success"; // Redirect to a success page
			} else {
				return "error"; // Redirect to an error page
			}
		} catch (ParseException e) {
			// Handle parsing errors
			return "insertDoctor";
		}
		boolean b = doctordao.createDoctorSchedule(doc);
		System.out.println("User Page Requested");
		model.addAttribute("empName", doc.getDoct_id());
		return "raju";
	}

}
