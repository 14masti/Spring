package com.masti.health.HealthManagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
